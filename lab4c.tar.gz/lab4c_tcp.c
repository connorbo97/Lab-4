//NAME:Connor Borden
//EMAIL:connorbo97@g.ucla.edu
//ID:004603469
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <errno.h>
#include "mraa/aio.h"
#include <math.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <poll.h>
#include <sys/socket.h> //socket api
#include <netdb.h>  //server helper functions

const int OFF    = 0;
const int STOP   = 1;
const int START  = 2;
const int SCALEF  = 3;
const int SCALEC  = 4;
const int PERIOD = 5;

int socketfd = -1;
struct sockaddr_in server_address;

mraa_aio_context adc_a0;
mraa_gpio_context gpio;
char* buf = NULL;
struct pollfd pollArr[2];
int logFlag = 0;
int logfd = -1;
char* inputBuf = NULL;
char* logString = NULL;
int keepReading = 1;
int seconds = 0;
int minutes = 0;
struct tm* timer;
time_t curTime;
int period = 1;
int scale = 0;                                          //0 is celsius, 1 is fahrenheit
char userID[100];
char host[100];
int port = -1;
char* tempOutputBuf;

void closeIOComponents();

void Exit(int num)
{
	close(socketfd);
	closeIOComponents();
	if(buf != NULL)
	{
			free(buf);
			buf = NULL;
	}
	if(inputBuf != NULL)
	{
			free(inputBuf);
			inputBuf = NULL;
	}
	if(logString != NULL)
	{
			free(logString);
			logString = NULL;
	}
	if(logFlag)
	{
			close(logfd);
	}
	exit(num);
}

int checkIsFile(const char *check)
{
	struct stat path;
	stat(check, &path);
	return S_ISREG(path.st_mode);
}


double getTemperature()
{
        int B = 4275;               // B value of the thermistor
        int R0 = 100000;            // R0 = 100k
        uint16_t adc_value = 0;
        adc_value = mraa_aio_read(adc_a0);
        float R = 1023.0/adc_value-1.0;
        R = R0*R;
        float temperature = 1.0/(log(R/R0)/B+1/298.15)-273.15; // convert to temperature via datasheet
        if(!scale)
                return temperature;
        else
        {
                temperature = temperature * 9 / 5;
                temperature += 32;
                return temperature;
        }
}

void handleArguments(int argc, char** argv)
{

        static struct option args[] =
        {
                {"id", required_argument, 0, 'i'},
                {"host", required_argument, 0, 'h'},
                {"log", required_argument, 0, 'l'},
                {0,0,0,0}

        };

        int option = 0;

        mode_t perm = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
		
		int hostFound = 0;
		int idFound = 0;
        while((option = getopt_long(argc,argv, "i:h:l", args, NULL)) != -1)
        {
                switch(option)
                {
                        case 'i':
                                if(strlen(optarg) != 9)
                                {
									fprintf(stderr, "ID must be 9 digits\n");
									Exit(1);
                                }
                                strcpy(userID, optarg);
								idFound = 1;
                                break;
                        case 'l':
                                logfd = open(optarg, O_WRONLY | O_CREAT| O_TRUNC, perm);
                                if(logfd == -1)
                                {
                                        if(checkIsFile(optarg) == 0)
                                        {
                                                fprintf(stderr, "Not a regular file");
                                                Exit(1);
                                        }
                                        if(access(optarg, W_OK) == -1)
                                        {
                                                fprintf(stderr, "Log file not writable");

                                                Exit(1);
                                        }
                                        fprintf(stderr, "Couldn't open log file");
                                        Exit(1);
                                }
                                logFlag = 1;
                                break;
                        case 'h':
								if(strlen(optarg) > 99)
								{
									fprintf(stderr, "Host must be less than 99 characters\n");
									Exit(1);
								}
								strcpy(host, optarg);
								hostFound = 1;
                                break;

                        default:
                                fprintf(stderr, "Correct flags are --id= 9 digit UID, --log=FILE used to store log information, or --host= name of host server and port number is required\n");
                                Exit(1);
                }
        }
		if(argc > optind)
		{
			port = atoi(argv[optind]);
		}
		else
		{
			fprintf(stderr, "Port number is required");
			Exit(1);
		}
		if(hostFound == 0)
		{
			strcpy(host, "lever.cs.ucla.edu");
		}
		if(idFound == 0)
		{
			strcpy(userID, "000000000");
		}
}

void passBytes(char* input, int out)
{
        int readCount = 0;
        int readSuccess = strlen(input);
        if(readSuccess > readCount)
        {
                char numBytes[5];
                int technicalTotal = readSuccess;
                int i;
                for(i = 0; i < readSuccess; i++)
                {
                        if(*(input + i) == '\r' || *(input + i) == '\n')
                        {
                                technicalTotal++;
                        }
                }
                sprintf(numBytes, "%d", technicalTotal);
        }
        while(readSuccess > readCount)
        {


                if(write(out, input + readCount, 1) == -1)
                {
                        fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
                        Exit(1);
                }

                readCount++;

        }
}

int analyzeCommand(int newline)
{
        inputBuf[1023] = '\0'; //making sure that the strcmp doesn't overflow
        if(strcmp(inputBuf, "OFF\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);
                        if(sprintf(logString,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
				if(sprintf(logString,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec) <= 0)
				{
						fprintf(stderr, "Failure during sprintf\n");
						Exit(1);
				}
				if(write(socketfd,logString, strlen(logString)) == -1)
				{
					fprintf(stderr, "Failure during write to socket\n");
					Exit(1);
				}	
                Exit(0);
                return OFF;
        }
        else if(strcmp(inputBuf, "STOP\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                keepReading = 0;
                return STOP;
        }
        else if(strcmp(inputBuf, "START\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                keepReading = 1;

                return START;
        }
        else if(strcmp(inputBuf, "SCALE=F\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                scale = 1;
                return SCALEF;
        }
        else if(strcmp(inputBuf, "SCALE=C\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                scale = 0;
                return SCALEC;
        }
        else
        {
                char* temp = (char*)malloc(sizeof(char) * 20);
                temp = strcpy(temp, inputBuf);
                temp[7] = '\0';
                if(strcmp(temp, "PERIOD=") == 0)
                {
                        //set new time
                        if(logFlag)
                        {
                                if(sprintf(logString,"%s", inputBuf) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                        }
                        inputBuf[newline] = '\0';
                        strcpy(temp, inputBuf + 7);
                        period = atoi(temp);
                        if(period < 0)
                        {
                                fprintf(stderr, "Period must be positive\n");
                                Exit(1);
                        }
                        time(&curTime);
                        timer = localtime(&curTime);
                        if(timer != NULL)
                        {
                                seconds = timer->tm_sec;
                                minutes = timer->tm_min;
                        }
                        strcpy(inputBuf, "");
                        free(temp);
                        return PERIOD;
                }
                else
                {
                        inputBuf[newline] = '\0';
                        free(temp);
                        if(logFlag)
                        {
                                if(sprintf(logString,"Incorrect command received: %s", inputBuf) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                        }
                        Exit(0);
                        return -2;
                }

        }
}



int getCommands(int in)
{
        int readSuccess = read(in, buf, 100);
        int readCount = 0;
        int lastRead = 0;
        char* hold = (char*)malloc(sizeof(char) * 2);
        if(*hold == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        hold[1] = '\0';
        while(readSuccess > readCount)
        {
                hold[0] = buf[readCount];
                strcat(inputBuf,hold);
                if(buf[readCount] == '\n')
                {
                //      free(hold);
                        analyzeCommand(readCount - lastRead);
                        lastRead = readCount;
                }
                readCount++;
        }
        if(readSuccess == 0)
        {
                Exit(0);
        }
        return 0;
}

void initializeIOComponents()
{
    adc_a0 = mraa_aio_init(0);
    if (adc_a0 == NULL) {
		fprintf(stderr, "Error while initializing io\n");
		Exit(1);
    }
}

void closeIOComponents()
{
    mraa_aio_close(adc_a0);

}


int main(int argc, char** argv)
{
        buf = (char*)malloc(sizeof(char) * 1024);
        if(*buf == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        strcpy(buf, "");

        inputBuf = (char*)malloc(sizeof(char) * 1024);
        inputBuf[0] = '\0';
        if(*inputBuf == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
		
        logString = (char*)malloc(sizeof(char) * 1024);
        logString[0] = '\0';
        if(*logString == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
		
        tempOutputBuf = (char*)malloc(sizeof(char) * 1024);
        tempOutputBuf[0] = '\0';
        if(*tempOutputBuf == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
		
       
        handleArguments(argc, argv);
        initializeIOComponents();

		socketfd = socket(AF_INET, SOCK_STREAM, 0);	
	
		if(socketfd == -1)
		{
			fprintf(stderr,"Failed to create socket to port.");
			Exit(1);
		}
		
		if ((socketfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			fprintf(stderr,"Failed to create socket to port.");
			exit(1);
		}
		//identify server host and port
		struct hostent *server_name = gethostbyname(host);

		bzero((char*) &server_address, sizeof(server_address));
		bcopy((char*) server_name->h_addr, (char*) &server_address.sin_addr.s_addr,
		server_name->h_length);

		server_address.sin_family = AF_INET;
		server_address.sin_port = htons(port);

		if ( connect(socketfd, (struct sockaddr *) &server_address, sizeof(server_address)) < 0)
		{
			fprintf(stderr,"Failed to create socket to port.");
		  exit(1);
		}
		
		
		char temporaryOut[100];
		strcpy(temporaryOut, "ID=");
		strcat(temporaryOut, userID);
		strcat(temporaryOut, "\n");
		if(write(socketfd,temporaryOut, 13) == -1)
		{
			fprintf(stderr, "Failure during write to socket\n");
			Exit(1);
		}			
		if(logFlag == 1)
		{
			
			if(write(logfd, temporaryOut, 13) == -1)
			{
				fprintf(stderr, "Failure during write to socket\n");
				Exit(1);
			}							
		}
		
        float temperature;

		pollArr[0] = (struct pollfd) {.fd = socketfd, .events = POLLIN};

        getTemperature();       //used to get rid of first bad temperature, always happens on my edison that first read is off by like 10 degrees
        time(&curTime);
        timer = localtime(&curTime);
        if(timer != NULL)
        {
                seconds = timer->tm_sec;
                minutes = timer->tm_min;
        }
        else
        {
                fprintf(stderr, "Failed during use of local time\n");
                Exit(1);
        }

        //makes sure we get at least 1 temperature in our log
        temperature = getTemperature();
        
		sprintf(tempOutputBuf,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
		if(write(socketfd,tempOutputBuf, strlen(tempOutputBuf) == -1))
		{
			fprintf(stderr, "Failure during write to socket\n");
			Exit(1);
		}							

        while(1)
        {
                int curSeconds;
                int curMinutes;
                time(&curTime);
                timer = localtime(&curTime);
                if(timer != NULL)
                {
                        curSeconds = timer->tm_sec;
                        curMinutes = timer->tm_min;
                }
                else
                {
                        fprintf(stderr, "Failed during use of local time\n");
                        Exit(1);
                }
                poll(pollArr,1,0);

                if(pollArr[0].revents == POLLIN)
                {
                      getCommands(socketfd);
                }
                int minuteDifference = 0;
                if(period >= 60)
                {
                        if(curMinutes< minutes)
                        {
                                minuteDifference = curMinutes + 60 -minutes;
                        }
                        else
                        {
                                minuteDifference = curMinutes - minutes;
                        }
                }
                int secondDifference = minuteDifference * 60;
                if(curSeconds < seconds)
                {
                        secondDifference += (curSeconds + 60 - seconds);
                }
                else
                {
                        secondDifference += (curSeconds - seconds);
                }
                if(secondDifference >= period && keepReading)
                {
                        temperature = getTemperature();
                        sprintf(tempOutputBuf,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
						if(write(socketfd,tempOutputBuf, strlen(tempOutputBuf)) == -1)
						{
							fprintf(stderr, "Failure during write to socket\n");
							Exit(1);
						}							
							
                        if(logFlag == 1)
                        {
                                if(sprintf(logString,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                                //fprintf(logfd,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
                        }
                        //fprintf(stdout,"CUR: %d:%d OLD: %d:%d\n", curMinutes, curSeconds, minutes, seconds);
                        minutes = curMinutes;
                        seconds = curSeconds;
                }
        }

        fprintf(stdout,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec);
        if(logFlag == 1)
        {
                if(sprintf(logString,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec) <= 0)
                {
                        fprintf(stderr, "Failure during sprintf\n");
                        Exit(1);
                }
                passBytes(logString, logfd);

        }
        Exit(0);

        return 2;       //should never happen
}
