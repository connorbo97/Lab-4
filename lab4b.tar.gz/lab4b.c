//NAME:Connor Borden
//EMAIL:connorbo97@g.ucla.edu
//ID:004603469

#include <math.h>
#include "mraa.h"
#include "mraa/aio.h"
#include <time.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>
#include <errno.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <sys/stat.h>

const int OFF    = 0;
const int STOP   = 1;
const int START  = 2;
const int SCALEF  = 3;
const int SCALEC  = 4;
const int PERIOD = 5;


mraa_aio_context adc_a0;
mraa_gpio_context gpio;
char* buf = NULL;
struct pollfd pollArr[2];
int logFlag = 0;
int logfd = -1;
char* inputBuf = NULL;
char* logString = NULL;
int keepReading = 1;
int seconds = 0;
int minutes = 0;
struct tm* timer;
time_t curTime;
int period = 1;
int scale = 0;                                          //0 is celsius, 1 is fahrenheit

void closeIOComponents();

void Exit(int num)
{
        closeIOComponents();
        if(buf != NULL)
        {
                free(buf);
                buf = NULL;
        }
        if(inputBuf != NULL)
        {
                free(inputBuf);
                inputBuf = NULL;
        }
        if(logString != NULL)
        {
                free(logString);
                logString = NULL;
        }
        if(logFlag)
        {
                close(logfd);
        }
        exit(num);
}

int checkIsFile(const char *check)
{
        struct stat path;
        stat(check, &path);
        return S_ISREG(path.st_mode);
}


double getTemperature()
{
        int B = 4275;               // B value of the thermistor
        int R0 = 100000;            // R0 = 100k
        uint16_t adc_value = 0;
        adc_value = mraa_aio_read(adc_a0);
        float R = 1023.0/adc_value-1.0;
        R = R0*R;
        float temperature = 1.0/(log(R/R0)/B+1/298.15)-273.15; // convert to temperature via datasheet
        if(!scale)
                return temperature;
        else
        {
                temperature = temperature * 9 / 5;
                temperature += 32;
                return temperature;
        }
}

void handleArguments(int argc, char** argv)
{

        static struct option args[] =
        {
                {"period", required_argument, 0, 'p'},
                {"scale", required_argument, 0, 's'},
                {"log", required_argument, 0, 'l'},
                {0,0,0,0}

        };

        int option = 0;

        mode_t perm = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
        while((option = getopt_long(argc,argv, "p:l:e", args, NULL)) != -1)
        {
                switch(option)
                {
                        case 'p':
                                period = atoi(optarg);
                                if(period < 0)
                                {
                                        fprintf(stderr, "Period must be positive\n");
                                        Exit(1);
                                }
                                break;
                        case 'l':
                                logfd = open(optarg, O_WRONLY | O_CREAT| O_TRUNC, perm);
                                if(logfd == -1)
                                {
                                        if(checkIsFile(optarg) == 0)
                                        {
                                                fprintf(stderr, "Not a regular file");
                                                Exit(1);
                                        }
                                        if(access(optarg, W_OK) == -1)
                                        {
                                                fprintf(stderr, "Log file not writable");

                                                Exit(1);
                                        }
                                        fprintf(stderr, "Couldn't open log file");
                                        Exit(1);
                                }
                                logFlag = 1;
                                break;
                        case 's':
                                if(strcmp(optarg,"F") == 0)
                                {
                                        scale = 1;
                                }
                                else if(strcmp(optarg,"C") == 0)
                                {
                                        scale = 0;
                                }
                                else
                                {
                                        fprintf(stderr, "Scale must be either F or C\n");
                                        Exit(1);
                                }

                                break;

                        default:
                                fprintf(stderr, "Correct flags are --period=# of seconds between samples, --log=FILE used to store log information, or --scale=F or C, where the samples are in Fahrenheit or Celsius\n");
                                Exit(1);
                }
        }
}

void passBytes(char* input, int out)
{
        int readCount = 0;
        int readSuccess = strlen(input);
        if(readSuccess > readCount)
        {
                char numBytes[5];
                int technicalTotal = readSuccess;
                int i;
                for(i = 0; i < readSuccess; i++)
                {
                        if(*(input + i) == '\r' || *(input + i) == '\n')
                        {
                                technicalTotal++;
                        }
                }
                sprintf(numBytes, "%d", technicalTotal);
        }
        while(readSuccess > readCount)
        {


                if(write(out, input + readCount, 1) == -1)
                {
                        fprintf(stderr, "Failed to write bits to %d: %s",out, strerror(errno));
                        Exit(1);
                }

                readCount++;

        }
}

int analyzeCommand(int newline)
{
        inputBuf[1023] = '\0'; //making sure that the strcmp doesn't overflow
        if(strcmp(inputBuf, "OFF\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);
                        if(sprintf(logString,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                Exit(0);
                return OFF;
        }
        else if(strcmp(inputBuf, "STOP\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                keepReading = 0;
                return STOP;
        }
        else if(strcmp(inputBuf, "START\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                keepReading = 1;

                return START;
        }
        else if(strcmp(inputBuf, "SCALE=F\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                scale = 1;
                return SCALEF;
        }
        else if(strcmp(inputBuf, "SCALE=C\n") == 0)
        {
                if(logFlag == 1)
                {
                        if(sprintf(logString,"%s", inputBuf) <= 0)
                        {
                                fprintf(stderr, "Failure during sprintf\n");
                                Exit(1);
                        }
                        passBytes(logString, logfd);

                }
                strcpy(inputBuf, "");
                scale = 0;
                return SCALEC;
        }
        else
        {
                char* temp = (char*)malloc(sizeof(char) * 20);
                temp = strcpy(temp, inputBuf);
                temp[7] = '\0';
                if(strcmp(temp, "PERIOD=") == 0)
                {
                        //set new time
                        if(logFlag)
                        {
                                if(sprintf(logString,"%s", inputBuf) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                        }
                        inputBuf[newline] = '\0';
                        strcpy(temp, inputBuf + 7);
                        period = atoi(temp);
                        if(period < 0)
                        {
                                fprintf(stderr, "Period must be positive\n");
                                Exit(1);
                        }
                        time(&curTime);
                        timer = localtime(&curTime);
                        if(timer != NULL)
                        {
                                seconds = timer->tm_sec;
                                minutes = timer->tm_min;
                        }
                        strcpy(inputBuf, "");
                        free(temp);
                        return PERIOD;
                }
                else
                {
                        inputBuf[newline] = '\0';
                        free(temp);
                        if(logFlag)
                        {
                                if(sprintf(logString,"Incorrect command received: %s", inputBuf) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                        }
                        Exit(0);
                        return -2;
                }

        }
}



int getCommands(int in)
{
        int readSuccess = read(in, buf, 100);
        int readCount = 0;
        int lastRead = 0;
        char* hold = (char*)malloc(sizeof(char) * 2);
        if(*hold == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        hold[1] = '\0';
        while(readSuccess > readCount)
        {
                hold[0] = buf[readCount];
                strcat(inputBuf,hold);
                if(buf[readCount] == '\n')
                {
                //      free(hold);
                        analyzeCommand(readCount - lastRead);
                        lastRead = readCount;
                }
                readCount++;
        }
        if(readSuccess == 0)
        {
                Exit(0);
        }
        return 0;
}

void initializeIOComponents()
{
    adc_a0 = mraa_aio_init(0);
    if (adc_a0 == NULL) {
                fprintf(stderr, "Error while initializing io\n");
        Exit(1);
    }
    gpio = mraa_gpio_init(3);
    mraa_gpio_dir(gpio, MRAA_GPIO_IN);
}

void closeIOComponents()
{
    mraa_aio_close(adc_a0);
    mraa_gpio_close(gpio);

}


int main(int argc, char** argv)
{
        buf = (char*)malloc(sizeof(char) * 1024);
        if(*buf == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        strcpy(buf, "");

        inputBuf = (char*)malloc(sizeof(char) * 1024);
        inputBuf[0] = '\0';
        if(*inputBuf == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        logString = (char*)malloc(sizeof(char) * 1024);
        if(*logString == -1)
        {
                fprintf(stderr, "Error while using malloc\n");
                Exit(1);
        }
        strcpy(logString, "");
        handleArguments(argc, argv);
        initializeIOComponents();


        /*              code that gives board name, just keeping just in case
        const char* board_name = mraa_get_platform_name();
    fprintf(stdout, "hello mraa\n Version: %s\n Running on %s\n", mraa_get_version(), board_name);
    mraa_deinit();
        */

        float temperature;

        pollArr[0] = (struct pollfd){.fd =0, .events = POLLIN};

        getTemperature();       //used to get rid of first bad temperature, always happens on my edison that first read is off by like 10 degrees
        time(&curTime);
        timer = localtime(&curTime);
        if(timer != NULL)
        {
                seconds = timer->tm_sec;
                minutes = timer->tm_min;
        }
        else
        {
                fprintf(stderr, "Failed during use of local time\n");
                Exit(1);
        }

        //makes sure we get at least 1 temperature in our log
        temperature = getTemperature();
        fprintf(stdout,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
        if(logFlag == 1)
        {
                if(sprintf(logString,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature) <= 0)
                {
                        fprintf(stderr, "Failure during sprintf\n");
                        Exit(1);
                }
                passBytes(logString, logfd);
        }

        while(mraa_gpio_read(gpio) == 0)
        {
                int curSeconds;
                int curMinutes;
                time(&curTime);
                timer = localtime(&curTime);
                if(timer != NULL)
                {
                        curSeconds = timer->tm_sec;
                        curMinutes = timer->tm_min;
                }
                else
                {
                        fprintf(stderr, "Failed during use of local time\n");
                        Exit(1);
                }
                poll(pollArr,1,0);

                if(pollArr[0].revents == POLLIN)
                {
                        getCommands(0);

                }
                int minuteDifference = 0;
                if(period >= 60)
                {
                        if(curMinutes< minutes)
                        {
                                minuteDifference = curMinutes + 60 -minutes;
                        }
                        else
                        {
                                minuteDifference = curMinutes - minutes;
                        }
                }
                int secondDifference = minuteDifference * 60;
                if(curSeconds < seconds)
                {
                        secondDifference += (curSeconds + 60 - seconds);
                }
                else
                {
                        secondDifference += (curSeconds - seconds);
                }
                if(secondDifference >= period && keepReading)
                {
                        temperature = getTemperature();
                        fprintf(stdout,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
                        if(logFlag == 1)
                        {
                                if(sprintf(logString,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature) <= 0)
                                {
                                        fprintf(stderr, "Failure during sprintf\n");
                                        Exit(1);
                                }
                                passBytes(logString, logfd);
                                //fprintf(logfd,"%02d:%02d:%02d %.1f\n", timer->tm_hour, timer->tm_min, timer->tm_sec, temperature);
                        }
                        //fprintf(stdout,"CUR: %d:%d OLD: %d:%d\n", curMinutes, curSeconds, minutes, seconds);
                        minutes = curMinutes;
                        seconds = curSeconds;
                }
        }

        fprintf(stdout,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec);
        if(logFlag == 1)
        {
                if(sprintf(logString,"%02d:%02d:%02d SHUTDOWN\n", timer->tm_hour, timer->tm_min, timer->tm_sec) <= 0)
                {
                        fprintf(stderr, "Failure during sprintf\n");
                        Exit(1);
                }
                passBytes(logString, logfd);

        }
        Exit(0);

        return 2;       //should never happen
}
